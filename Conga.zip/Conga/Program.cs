﻿using System;

namespace Conga
{
    class Program
    {
        private static string filePath = string.Format(@"{0}\Resource\Wordlist.txt", Environment.CurrentDirectory);

        static void Main(string[] args)
        {
            Console.WriteLine("Enter a word to check Anagram.");
            Console.WriteLine("Press 'e' to exit.");
            Console.WriteLine("..................");

            IAnagramWord anagramWord = new AnagramWord();
            var wordList = anagramWord.PrepareWordList(filePath);
            string inputWord;
            do
            {
                inputWord = Console.ReadLine();
                foreach (var word in wordList)
                {
                    if (anagramWord.CheckAnagram(inputWord, word))
                    {
                        Console.WriteLine("{0} and {1}, both words are anagram words.", inputWord, word);
                    }
                }

            } while (inputWord.ToLower() != "e");
        }

    }
}
