﻿using System.Collections.Generic;

namespace Conga
{
    /// <summary>
    /// The contract which handle anagram words related operations
    /// </summary>
    public interface IAnagramWord
    {
        /// <summary>
        /// Read the file to prepare the work list for anagram.
        /// </summary>
        /// <param name="filePath">The file location.</param>
        /// <returns>List of words.</returns>
        List<string> PrepareWordList(string filePath);

        /// <summary>
        /// Check the given two words are anagram or not.
        /// </summary>
        /// <param name="firstWord">The first word string.</param>
        /// <param name="secondWord">The second word string.</param>
        /// <returns>True or false. Whether the give words are anagram or not.</returns>
        bool CheckAnagram(string firstWord, string secondWord);
    }
}
