﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Conga
{
    /// <summary>
    /// The class which handle anagram words related operations
    /// </summary>
    public class AnagramWord: IAnagramWord
    {
       /// <inheritdoc/>
        public List<string> PrepareWordList(string filePath)
        {
            List<string> wordList = new List<string>();
            try
            {
                using (var sr = new StreamReader(filePath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        wordList.Add(line.Trim());
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return wordList;
        }

        /// <inheritdoc/>
        public bool CheckAnagram(string firstWord, string secondWord)
        {
            if (firstWord.Length != secondWord.Length)
            {
                return false;
            }
            char[] inputWordArray = firstWord.ToLower().ToCharArray();
            char[] secondWordArray = secondWord.ToLower().ToCharArray();

            Array.Sort(inputWordArray);
            Array.Sort(secondWordArray);

            for (int i = 0; i < inputWordArray.Length; i++)
            {
                if (inputWordArray[i].ToString() != secondWordArray[i].ToString())
                {
                    return false;
                }
            }
            return true;
        }
    }
}
